﻿
// ThreadView.h: CThreadView 클래스의 인터페이스
//

#pragma once

struct SData
{
	int array[10] = { 11,3,2,6,7,4,8,10,9,5 };
	int min = 1;
	HWND NotifyWindow;
};
class CThreadView : public CView
{
protected: // serialization에서만 만들어집니다.
	CThreadView();
	DECLARE_DYNCREATE(CThreadView)

// 특성입니다.
public:
	CThreadDoc* GetDocument() const;

// 작업입니다.
public:

// 재정의입니다.
public:
	virtual void OnDraw(CDC* pDC);  // 이 뷰를 그리기 위해 재정의되었습니다.
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// 구현입니다.
public:
	virtual ~CThreadView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 생성된 메시지 맵 함수
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnFindmin();
	SData data;
	CWinThread* Thread;
	LRESULT OnMinFound(WPARAM wParam, LPARAM lParam);
};

#ifndef _DEBUG  // ThreadView.cpp의 디버그 버전
inline CThreadDoc* CThreadView::GetDocument() const
   { return reinterpret_cast<CThreadDoc*>(m_pDocument); }
#endif

